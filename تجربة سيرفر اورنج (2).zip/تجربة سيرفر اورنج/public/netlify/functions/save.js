import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

export async function handler(event, context) {
  if (event.httpMethod === "POST") {
    const body = JSON.parse(event.body);
    const { name, idNumber, loanAmount, address, job, orange } = body;

    try {
      const { data, error } = await supabase
        .from('loan_requests')
        .insert([{ name, idNumber, loanAmount, address, job, orange }]);

      if (error) {
        return {
          statusCode: 400,
          body: JSON.stringify({ error: error.message })
        };
      }

      return {
        statusCode: 200,
        body: JSON.stringify({ message: "تم حفظ البيانات بنجاح", data })
      };
    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "خطأ في السيرفر: " + err.message })
      };
    }
  }

  return {
    statusCode: 405,
    body: JSON.stringify({ error: "Method Not Allowed" })
  };
}
